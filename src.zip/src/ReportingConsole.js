import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { TutorialHighlight } from './App';
import { AnimatePresence } from 'framer-motion';
import { collection, onSnapshot } from 'firebase/firestore';

// Import the new sub-components
import ReportFilters from './ReportFilters';
import ReportDisplay from './ReportDisplay';
import MovableJobFamilyDisplay from './MovableJobFamilyDisplay';
import GeminiInsightChat from './GeminiInsightChat';
import JobFamilyEditor from './JobFamilyEditor'; // Import JobFamilyEditor

const ReportingConsole = ({ projects = [], detailers = [], assignments = [], tasks = [], allProjectActivities = [], currentTheme, geminiApiKey, accessLevel, db, appId }) => {
    // State for filters (managed here, passed to ReportFilters)
    const [reportType, setReportType] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [selectedProjectId, setSelectedProjectId] = useState('');
    const [selectedLevels, setSelectedLevels] = useState([]);
    const [selectedTrade, setSelectedTrade] = useState('');
    const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
    const [reportOption, setReportOption] = useState('fullProject');
    const [collapsedFilters, setCollapsedFilters] = useState({
        level: true, trade: true, employee: true, project: true, dateRange: true, jobFamily: true, reportOptions: true
    });

    // State for report results (managed here, passed to ReportDisplay)
    const [reportData, setReportData] = useState(null);
    const [reportHeaders, setReportHeaders] = useState([]);
    const [chartData, setChartData] = useState(null);
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });

    // State for modals/popups
    const [isGeminiVisible, setIsGeminiVisible] = useState(false);
    const [reportContext, setReportContext] = useState(null); // Context for Gemini AI
    const [isJobFamilyPopupVisible, setIsJobFamilyPopupVisible] = useState(false);
    const [jobFamilyToDisplayInPopup, setJobFamilyToDisplayInPopup] = useState(null);
    const [isJobFamilyEditorOpen, setIsJobFamilyEditorOpen] = useState(false); // New state for JobFamilyEditor modal

    // Data fetched from Firestore (shared across components)
    const [jobFamilyData, setJobFamilyData] = useState({});

    // This effect listens for the global 'close-overlays' event dispatched from App.js
    // and closes all modals/popups within this console.
    useEffect(() => {
        const handleClose = () => {
            setIsGeminiVisible(false);
            setIsJobFamilyPopupVisible(false);
            setIsJobFamilyEditorOpen(false);
        };
        window.addEventListener('close-overlays', handleClose);
        return () => window.removeEventListener('close-overlays', handleClose);
    }, []); // Empty dependency array ensures this runs only once.

    // Fetch job family data from Firestore
    useEffect(() => {
        if (!db || !appId) return;
        const jobFamilyRef = collection(db, `artifacts/${appId}/public/data/jobFamilyData`);
        const unsubscribe = onSnapshot(jobFamilyRef, (snapshot) => {
            const data = {};
            snapshot.docs.forEach(doc => {
                data[doc.data().title] = { id: doc.id, ...doc.data() };
            });
            setJobFamilyData(data);
        });
        return () => unsubscribe();
    }, [db, appId]);

    // Derived data for filters
    const uniqueTitles = useMemo(() => [...new Set(detailers.map(d => d.title).filter(Boolean))].sort(), [detailers]);
    const uniqueTrades = useMemo(() => {
        const trades = new Set();
        detailers.forEach(d => {
            if (Array.isArray(d.disciplineSkillsets) && d.disciplineSkillsets.length > 0) {
                trades.add(d.disciplineSkillsets[0].name);
            } else if (d.disciplineSkillsets && !Array.isArray(d.disciplineSkillsets) && Object.keys(d.disciplineSkillsets).length > 0) {
                trades.add(Object.keys(d.disciplineSkillsets)[0]);
            }
        });
        return [...trades].sort();
    }, [detailers]);

    // Helper for date range calculation
    const getDaysInRange = useCallback((assStart, assEnd, reportStart, reportEnd) => {
        const effectiveStart = Math.max(assStart.getTime(), reportStart.getTime());
        const effectiveEnd = Math.min(assEnd.getTime(), reportEnd.getTime());
        if (effectiveStart > effectiveEnd) return 0;
        const diffTime = Math.abs(effectiveEnd - effectiveStart);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    }, []);

    // Helper for project activities map
    const projectActivitiesMap = useMemo(() => {
        const map = new Map();
        allProjectActivities.forEach(activityDoc => {
            map.set(activityDoc.id, activityDoc);
        });
        return map;
    }, [allProjectActivities]);

    // Filtered detailers for skill matrix (passed to ReportDisplay)
    const filteredDetailersForMatrix = useMemo(() => {
        let filtered = [...detailers];
        if (selectedLevels.length > 0) {
            filtered = filtered.filter(d => selectedLevels.includes(d.title));
        }
        if (selectedTrade) {
            filtered = filtered.filter(d => {
                const primaryTrade = d.disciplineSkillsets && Array.isArray(d.disciplineSkillsets) && d.disciplineSkillsets.length > 0 ? d.disciplineSkillsets[0].name : null;
                return primaryTrade === selectedTrade;
            });
        }
        return filtered;
    }, [detailers, selectedLevels, selectedTrade]);

    // Report Generation Logic
    const handleGenerateReport = useCallback(() => {
        setReportData(null);
        setReportHeaders([]);
        setChartData(null);
        setSortConfig({ key: null, direction: 'ascending' });
        setIsJobFamilyPopupVisible(false); // Close job family popup on new report generation

        const sDate = startDate ? new Date(startDate) : null;
        const eDate = endDate ? new Date(endDate) : null;
        if (eDate) eDate.setHours(23, 59, 59, 999);

        let data = [];
        let headers = [];
        let isTabularReport = false;

        switch (reportType) {
            case 'full-project-report':
                if (!selectedProjectId) {
                    alert("Please select a project.");
                    return;
                }
                isTabularReport = false; // This is a complex view, not a simple table
                
                const project = projects.find(p => p.id === selectedProjectId);
                const activitiesDoc = projectActivitiesMap.get(selectedProjectId);
    
                if (!project || !activitiesDoc) {
                    alert("Could not find all data for the selected project.");
                    return;
                }
    
                const currentBudget = (project.initialBudget || 0) + (activitiesDoc.budgetImpacts || []).reduce((sum, impact) => sum + impact.amount, 0);
                
                const allActivities = Object.values(activitiesDoc.activities || {}).flat();
    
                const calculateTotals = (activitiesList) => {
                  return activitiesList.reduce((acc, activity) => {
                    const estHours = Number(activity?.estimatedHours || 0);
                    const costToDate = Number(activity?.costToDate || 0);
                    const percentComplete = Number(activity?.percentComplete || 0);
            
                    const useVdcRate = activity.description.toUpperCase().includes('VDC') || activity.description === "Project Setup";
                    const rateToUse = useVdcRate ? (project.vdcBlendedRate || project.blendedRate || 0) : (project.blendedRate || 0);
            
                    const budget = (estHours * rateToUse); // Using raw budget for calcs
                    const projectedCost = percentComplete > 0 ? (costToDate / (percentComplete / 100)) : (estHours > 0 ? budget : 0);
            
                    acc.estimated += estHours;
                    acc.budget += budget;
                    acc.actualCost += costToDate;
                    acc.earnedValue += budget * (percentComplete / 100);
                    acc.projectedCost += projectedCost;
                    
                    return acc;
                  }, { estimated: 0, budget: 0, actualCost: 0, earnedValue: 0, projectedCost: 0 });
                };
    
                const activityTotals = calculateTotals(allActivities);
                
                const actionTrackerSummary = [];
                if (activitiesDoc.mainItems && activitiesDoc.actionTrackerData) {
                    activitiesDoc.mainItems.forEach(main => {
                        const mainSummary = { mainName: main.name, disciplines: [] };
                        (activitiesDoc.actionTrackerDisciplines || []).forEach(disc => {
                            const tradeData = activitiesDoc.actionTrackerData[main.id]?.[disc.key];
                            if (tradeData) {
                                let totalCompletion = 0;
                                let activityCount = 0;
                                if(tradeData.activities){
                                    const completions = Object.values(tradeData.activities);
                                    activityCount = completions.length;
                                    if(activityCount > 0){
                                       totalCompletion = completions.reduce((sum, val) => sum + (Number(val) || 0), 0) / activityCount;
                                    }
                                }
                                mainSummary.disciplines.push({
                                    disciplineName: disc.label,
                                    tradePercentage: tradeData.tradePercentage || 0,
                                    avgPercentComplete: totalCompletion.toFixed(1)
                                });
                            }
                        });
                        actionTrackerSummary.push(mainSummary);
                    });
                }
    
                const fullReportPayload = {
                    project,
                    activitiesDoc,
                    financialSummary: {
                        currentBudget,
                        allocatedHours: activityTotals.estimated,
                        spentToDate: activityTotals.actualCost,
                        earnedValue: activityTotals.earnedValue,
                        projectedFinalCost: activityTotals.projectedCost,
                        costToComplete: activityTotals.projectedCost - activityTotals.actualCost,
                        variance: currentBudget - activityTotals.projectedCost,
                        productivity: activityTotals.actualCost > 0 ? activityTotals.earnedValue / activityTotals.actualCost : 0
                    },
                    actionTrackerSummary,
                    reportOption,
                    dateRange: { startDate: sDate, endDate: eDate }
                };
    
                setReportData(fullReportPayload);
                data = fullReportPayload; // Store for reportContext
                break;

            case 'project-health':
                const healthData = projects.filter(p => !p.archived).map(p => {
                    const activitiesDoc = projectActivitiesMap.get(p.id);
                    if (!activitiesDoc || !activitiesDoc.activities) return null;
                    const activities = activitiesDoc.activities;

                    let earnedValue = 0;
                    let actualCost = 0;
            
                    Object.entries(activities).forEach(([groupKey, activityList]) => {
                        const isVdcGroup = groupKey === 'vdc';
                        const rate = isVdcGroup ? (p.vdcBlendedRate || p.blendedRate) : p.blendedRate;
            
                        activityList.forEach(act => {
                            earnedValue += (Number(act.estimatedHours || 0) * rate * (Number(act.percentComplete || 0) / 100));
                            actualCost += (Number(act.costToDate || 0)); // Use costToDate directly
                        });
                    });

                    const projectAssignments = assignments.filter(a => a.projectId === p.id);
                    if(projectAssignments.length === 0) return null;

                    const minDate = new Date(Math.min(...projectAssignments.map(a => new Date(a.startDate).getTime())));
                    const maxDate = new Date(Math.max(...projectAssignments.map(a => new Date(a.endDate).getTime())));
                    const totalDuration = maxDate - minDate;
                    const elapsedDuration = new Date() - minDate;
                    const percentElapsed = totalDuration > 0 ? Math.min(1, elapsedDuration / totalDuration) : 0;
                    const plannedValue = p.initialBudget * percentElapsed;

                    return {
                        name: p.name,
                        budget: p.initialBudget,
                        costVariance: earnedValue - actualCost,
                        scheduleVariance: earnedValue - plannedValue
                    };
                }).filter(Boolean);
                setChartData(healthData);
                break;
            
            case 'employee-workload-dist':
                if (!selectedEmployeeId) {
                    alert("Please select an employee.");
                    return;
                }
                if (!sDate || !eDate) {
                    alert("Please select a date range.");
                    return;
                }
                const employeeAssignments = assignments.filter(a => a.detailerId === selectedEmployeeId);
                const workloadData = employeeAssignments.reduce((acc, ass) => {
                    const project = projects.find(p => p.id === ass.projectId);
                    if(!project) return acc;

                    const assStartDate = new Date(ass.startDate);
                    const assEndDate = new Date(ass.endDate);

                    if (isNaN(assStartDate.getTime()) || isNaN(assEndDate.getTime())) {
                        return acc;
                    }

                    // Use getDaysInRange to calculate calendar days within the selected date range
                    const calendarDays = getDaysInRange(assStartDate, assEndDate, sDate, eDate);
                    
                    if (calendarDays > 0) {
                        // Convert calendar days to approximate workdays (5/7 ratio)
                        const workDays = Math.ceil(calendarDays * (5/7));
                        const allocation = Number(ass.allocation) || 0;
                        const hours = workDays * 8 * (allocation / 100);

                        if (!acc[project.id]) {
                            acc[project.id] = { projectName: project.name, hours: 0 };
                        }
                        acc[project.id].hours += hours;
                    }
                    return acc;
                }, {});
                setChartData(Object.values(workloadData));
                break;

            case 'skill-matrix':
                // Build skill matrix data for Gemini context
                const skillMatrixData = filteredDetailersForMatrix.map(d => {
                    const skills = {};
                    // Core skills
                    if (d.coreSkillsets) {
                        d.coreSkillsets.forEach(skill => {
                            skills[skill.name] = skill.level;
                        });
                    }
                    // Discipline skills
                    if (d.disciplineSkillsets) {
                        d.disciplineSkillsets.forEach(skill => {
                            skills[skill.name] = skill.level;
                        });
                    }
                    // Software skills
                    if (d.softwareSkillsets) {
                        d.softwareSkillsets.forEach(skill => {
                            skills[skill.name] = skill.level;
                        });
                    }
                    return {
                        name: `${d.firstName} ${d.lastName}`,
                        title: d.title,
                        primaryTrade: d.disciplineSkillsets?.[0]?.name || 'N/A',
                        skills
                    };
                });
                
                // Set context for Gemini
                setReportContext({ 
                    data: skillMatrixData, 
                    headers: ['Employee', 'Title', 'Primary Trade', 'Skills'], 
                    type: reportType,
                    filters: {
                        selectedLevels: selectedLevels.length > 0 ? selectedLevels : 'All',
                        selectedTrade: selectedTrade || 'All'
                    }
                });
                break;

            case 'project-hours':
                headers = ["Project Name", "Project ID", "Total Allocated Hours"];
                const hoursByProject = assignments.reduce((acc, ass) => {
                    if (!sDate || !eDate) return acc;

                    const assStartDate = new Date(ass.startDate);
                    const assEndDate = new Date(ass.endDate);

                    const daysInRage = getDaysInRange(assStartDate, assEndDate, sDate, eDate);

                    if (daysInRage > 0) {
                        const project = projects.find(p => p.id === ass.projectId);
                        if (project) {
                            if (!acc[project.id]) {
                                acc[project.id] = { name: project.name, id: project.projectId, hours: 0 };
                            }
                            const dailyHours = (Number(ass.allocation) / 100) * 8;
                            acc[project.id].hours += daysInRage * dailyHours;
                        }
                    }
                    return acc;
                }, {});
                data = Object.values(hoursByProject).map(p => [p.name, p.id, p.hours.toFixed(2)]);
                isTabularReport = true;
                break;
            
            case 'detailer-workload':
                 headers = ["Detailer", "Total Hours", "Projects"];
                 const hoursByDetailer = assignments.reduce((acc, ass) => {
                    if (!sDate || !eDate) return acc;
                    const assStartDate = new Date(ass.startDate);
                    const assEndDate = new Date(ass.endDate);
                    
                    const daysInRage = getDaysInRange(assStartDate, assEndDate, sDate, eDate);

                    if(daysInRage > 0) {
                        const detailer = detailers.find(d => d.id === ass.detailerId);
                        if(detailer) {
                            if(!acc[detailer.id]) {
                                acc[detailer.id] = { name: `${detailer.firstName} ${detailer.lastName}`, hours: 0, projects: new Set() };
                            }
                            const project = projects.find(p => p.id === ass.projectId);
                            const dailyHours = (Number(ass.allocation) / 100) * 8;
                            acc[detailer.id].hours += daysInRage * dailyHours;
                            if(project) acc[detailer.id].projects.add(project.name);
                        }
                    }
                    return acc;
                 }, {});
                 data = Object.values(hoursByDetailer).map(d => [d.name, d.hours.toFixed(2), Array.from(d.projects).join(', ')]);
                 isTabularReport = true;
                 break;

            case 'task-status':
                headers = ["Task Name", "Project", "Assignee", "Status", "Due Date"];
                data = tasks
                    .filter(t => {
                        if (!t.dueDate) return true;
                        const taskDueDate = new Date(t.dueDate);
                        return (!sDate || taskDueDate >= sDate) && (!eDate || taskDueDate <= eDate);
                    })
                    .map(task => {
                        const project = projects.find(p => p.id === task.projectId);
                        const assignee = detailers.find(d => d.id === task.detailerId);
                        return [
                            task.taskName,
                            project ? project.name : 'N/A',
                            assignee ? `${assignee.firstName} ${assignee.lastName}` : 'N/A',
                            task.status,
                            task.dueDate || 'N/A'
                        ];
                    });
                isTabularReport = true;
                break;

            default:
                break;
        }
        
        if (reportType !== 'full-project-report') {
            setReportData(data);
        }
        
        setReportHeaders(headers);

        // Set reportContext for Gemini AI
        if (isTabularReport) {
            setReportContext({ data, headers, type: reportType });
        } else if (reportType === 'full-project-report' && data) {
            setReportContext({ data, headers: [], type: reportType });
        } else if (reportType !== 'skill-matrix') {
            // Don't clear for skill-matrix - it sets its own context above
            setReportContext(null);
        }
    }, [startDate, endDate, reportType, projects, projectActivitiesMap, assignments, selectedEmployeeId, detailers, getDaysInRange, tasks, selectedProjectId, reportOption, selectedLevels, selectedTrade, filteredDetailersForMatrix]);

    const handleClearReport = useCallback(() => {
        setReportData(null);
        setChartData(null);
        setReportHeaders([]);
        setSortConfig({ key: null, direction: 'ascending' });
        // Reset all filter states
        setReportType('');
        setStartDate('');
        setEndDate('');
        setSelectedProjectId('');
        setSelectedLevels([]);
        setSelectedTrade('');
        setSelectedEmployeeId('');
        setReportOption('fullProject');
        // Close modals/popups
        setIsJobFamilyPopupVisible(false);
        setJobFamilyToDisplayInPopup(null);
    }, []);

    // Effect to listen for the hotkey combination for Gemini AI
    useEffect(() => {
        const handleKeyDown = (event) => {
            if (
                event.ctrlKey &&
                event.shiftKey &&
                event.altKey &&
                event.key.toLowerCase() === 'g' &&
                accessLevel === 'taskmaster' &&
                reportContext
            ) {
                event.preventDefault();
                setIsGeminiVisible(prev => !prev);
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [accessLevel, reportContext]);

    // Callback for filter changes from ReportFilters
    const handleFilterChange = useCallback((filterName, value) => {
        switch (filterName) {
            case 'reportType': setReportType(value); break;
            case 'startDate': setStartDate(value); break;
            case 'endDate': setEndDate(value); break;
            case 'selectedProjectId': setSelectedProjectId(value); break;
            case 'selectedLevels': setSelectedLevels(value); break;
            case 'selectedTrade': setSelectedTrade(value); break;
            case 'selectedEmployeeId': setSelectedEmployeeId(value); break;
            case 'reportOption': setReportOption(value); break;
            default: break;
        }
    }, []);

    // Callback for toggling filter sections
    const toggleFilterCollapse = useCallback((filterName) => {
        setCollapsedFilters(prev => ({ ...prev, [filterName]: !prev[filterName] }));
    }, []);

    // Callback for displaying job family popup
    const handleJobFamilySelectForPopup = useCallback((jobTitle) => {
        if (jobTitle) {
            setJobFamilyToDisplayInPopup(jobFamilyData[jobTitle]);
            setIsJobFamilyPopupVisible(true);
        } else {
            setIsJobFamilyPopupVisible(false);
            setJobFamilyToDisplayInPopup(null);
        }
    }, [jobFamilyData]);

    // Callback for sorting report data
    const requestSort = useCallback((key) => {
        setSortConfig(prev => {
            let direction = 'ascending';
            if (prev.key === key && prev.direction === 'ascending') {
                direction = 'descending';
            }
            return { key, direction };
        });
    }, []);

    return (
        <TutorialHighlight tutorialKey="reporting">
            <div className="p-4 h-full flex flex-col">
                <style>
                    {`
                        @media print {
                            /* Skill Matrix printing only - Full Project Report uses popup window */
                            @page {
                                size: letter portrait;
                                margin: 0.25in;
                            }
                            
                            /* Hide everything except skill matrix */
                            body * {
                                visibility: hidden;
                            }
                            
                            #skill-matrix-printable-area,
                            #skill-matrix-printable-area * {
                                visibility: visible !important;
                            }
                            
                            #skill-matrix-printable-area {
                                position: absolute !important;
                                left: 0 !important;
                                top: 0 !important;
                                width: 100% !important;
                            }
                            
                            /* Color printing */
                            * {
                                -webkit-print-color-adjust: exact !important;
                                print-color-adjust: exact !important;
                                color-adjust: exact !important;
                            }
                        }
                    `}
                </style>
                {/* Gemini AI Chat Overlay */}
                <GeminiInsightChat
                    isVisible={isGeminiVisible}
                    onClose={() => setIsGeminiVisible(false)}
                    reportContext={reportContext}
                    geminiApiKey={geminiApiKey}
                    currentTheme={currentTheme}
                    jobFamilyData={jobFamilyData}
                />
                {/* Movable Job Family Display Popup */}
                <AnimatePresence>
                    {isJobFamilyPopupVisible && (
                        <MovableJobFamilyDisplay
                            jobToDisplay={jobFamilyToDisplayInPopup}
                            currentTheme={currentTheme}
                            onClose={() => {
                                setIsJobFamilyPopupVisible(false);
                                setJobFamilyToDisplayInPopup(null);
                            }}
                        />
                    )}
                </AnimatePresence>
                {/* JobFamilyEditor Modal */}
                <AnimatePresence>
                    {isJobFamilyEditorOpen && (
                        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center">
                            <div className={`bg-gray-800 p-6 rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto hide-scrollbar-on-hover`}>
                                <JobFamilyEditor
                                    db={db}
                                    appId={appId}
                                    currentTheme={currentTheme}
                                    onClose={() => setIsJobFamilyEditorOpen(false)}
                                />
                            </div>
                        </div>
                    )}
                </AnimatePresence>

                <div className="flex-shrink-0 mb-4 flex justify-between items-center">
                    <h2 className={`text-2xl font-bold ${currentTheme.textColor}`}>Reporting & Dashboards</h2>
                    {accessLevel === 'taskmaster' && (
                        <TutorialHighlight tutorialKey="manageJobPositions">
                            <button
                                onClick={() => setIsJobFamilyEditorOpen(true)}
                                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                            >
                                Manage Positions
                            </button>
                        </TutorialHighlight>
                    )}
                </div>

                <div className="flex-grow flex gap-4 min-h-0 h-[calc(100vh-200px)] overflow-y-auto hide-scrollbar-on-hover">
                    {/* Left Controls Column - now ReportFilters Component */}
                    <ReportFilters
                        reportType={reportType}
                        startDate={startDate}
                        endDate={endDate}
                        selectedProjectId={selectedProjectId}
                        selectedLevels={selectedLevels}
                        selectedTrade={selectedTrade}
                        selectedEmployeeId={selectedEmployeeId}
                        reportOption={reportOption}
                        collapsedFilters={collapsedFilters}
                        jobFamilyToDisplayInPopup={jobFamilyToDisplayInPopup}
                        jobFamilyData={jobFamilyData}
                        uniqueTitles={uniqueTitles}
                        uniqueTrades={uniqueTrades}
                        detailers={detailers}
                        projects={projects}
                        currentTheme={currentTheme}
                        onFilterChange={handleFilterChange}
                        onGenerateReport={handleGenerateReport}
                        onToggleFilterCollapse={toggleFilterCollapse}
                        onJobFamilySelectForPopup={handleJobFamilySelectForPopup}
                    />
                    
                    {/* Right Display Area - now ReportDisplay Component */}
                    <ReportDisplay
                        reportData={reportData}
                        reportHeaders={reportHeaders}
                        chartData={chartData}
                        reportType={reportType}
                        sortConfig={sortConfig}
                        currentTheme={currentTheme}
                        filteredDetailersForMatrix={filteredDetailersForMatrix}
                        accessLevel={accessLevel}
                        db={db}
                        appId={appId}
                        onClearReport={handleClearReport}
                        onRequestSort={requestSort}
                        assignments={assignments}
                        detailers={detailers}
                    />
                </div>
            </div>
        </TutorialHighlight>
    );
};

export default ReportingConsole;